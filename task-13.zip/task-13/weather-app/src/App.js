import React, { useState, useEffect } from "react";

const API_KEY = "f31a979dcb289df17e21ab599ab215c6";

function App() {
  const [city, setCity] = useState("London");
  const [weather, setWeather] = useState(null);
  const [forecast, setForecast] = useState([]);
  const [error, setError] = useState("");

  useEffect(() => {
    fetchWeather(city);
    fetchForecast(city);
  }, [city]);

  const fetchWeather = async (cityName) => {
    try {
      setError("");
      const res = await fetch(
        `https://api.openweathermap.org/data/2.5/weather?q=${cityName}&appid=${API_KEY}&units=metric`
      );

      if (!res.ok) throw new Error("City not found");

      const data = await res.json();
      setWeather(data);
    } catch (err) {
      setError(err.message);
      setWeather(null);
    }
  };

  const fetchForecast = async (cityName) => {
    try {
      const res = await fetch(
        `https://api.openweathermap.org/data/2.5/forecast?q=${cityName}&appid=${API_KEY}&units=metric`
      );

      if (!res.ok) throw new Error("Forecast not available");

      const data = await res.json();

      const daily = data.list.filter((item) =>
        item.dt_txt.includes("12:00:00")
      );

      setForecast(daily);
    } catch (err) {
      setForecast([]);
    }
  };

  const handleSearch = (e) => {
    e.preventDefault();
    const input = e.target.city.value;
    if (input) setCity(input);
  };

  return (
    <div style={{ textAlign: "center", padding: "20px" }}>
      <h1>Weather App</h1>

      <form onSubmit={handleSearch}>
        <input type="text" name="city" placeholder="Enter city" />
        <button type="submit">Search</button>
      </form>

      {error && <p style={{ color: "red" }}>{error}</p>}

      {weather && (
        <div>
          <h2>{weather.name}</h2>
          <p>Temperature: {weather.main.temp} °C</p>
          <p>Humidity: {weather.main.humidity}%</p>
          <p>Condition: {weather.weather[0].description}</p>
        </div>
      )}

      <h3>5-Day Forecast</h3>
      <div style={{ display: "flex", justifyContent: "center", gap: "10px" }}>
        {forecast.map((day, index) => (
          <div key={index} style={{ border: "1px solid #ccc", padding: "10px" }}>
            <p>{day.dt_txt.split(" ")[0]}</p>
            <p>{day.main.temp} °C</p>
            <p>{day.weather[0].main}</p>
          </div>
        ))}
      </div>
    </div>
  );
}

export default App;